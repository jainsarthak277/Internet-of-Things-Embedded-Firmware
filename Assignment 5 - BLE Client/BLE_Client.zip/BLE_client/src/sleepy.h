void sleepy(void);
void BlockSleep(int);
void UnblockSleep(int);

uint16_t sleep_counter[5] = {0,0,0,0,0};
