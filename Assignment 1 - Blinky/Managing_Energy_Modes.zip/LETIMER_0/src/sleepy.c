#include "sleep.h"
#include "src/main.h"
#include "em_emu.h"
#include "src/cmu.h"

void sleepy(void)
{
	if (mode == sleepEM0)
		return;
	else if (mode == sleepEM1)
			 return;
	else if (mode == sleepEM2)
			 EMU_EnterEM1();
	else if (mode == sleepEM3)
			 EMU_EnterEM2(false);
	else if (mode == sleepEM4)
			 EMU_EnterEM3(false);
	return;
}
