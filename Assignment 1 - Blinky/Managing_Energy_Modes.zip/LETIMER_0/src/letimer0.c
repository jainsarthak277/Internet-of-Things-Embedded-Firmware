/*
 * letimer0.c
 *
 *  Created on: Sep 13, 2018
 *      Author: jains
 */
#include "src/main.h"
#include "src/letimer0.h"
#include "em_core.h"
#include "em_letimer.h"
#include "em_gpio.h"
#include "sleep.h"
#include "src/gpio.h"
#include "src/cmu.h"

int freq, j;
float freqlo;

void letimer_setup(void)
{
	const LETIMER_Init_TypeDef letimerInit =
	{
			.enable = false,
			.debugRun = false,
			.comp0Top = true,
			.bufTop = false,
			.out0Pol = 0,
			.out1Pol = 0,
			.ufoa0 = letimerUFOANone,
			.ufoa1 = letimerUFOANone,
			.repMode = letimerRepeatFree
	};
	LETIMER_Init(LETIMER0, &letimerInit);
	int comp0_value;
	freq = 32768;
	freqlo = 1000;
	if (mode == sleepEM0 || mode == sleepEM1 || mode == sleepEM2 || mode == sleepEM3)
	{
		if (time_p>2)
		{
			int ticks = freq*time_p;
			int index = ticks/65535;
			//CMU->LFAPRESCO = index;
			j = pow(2,index);
			CMU_ClockDivSet(cmuClock_LETIMER0, j);
			comp0_value = ticks/j;
		}
		else comp0_value = freq*time_p;
	}
	else if (mode == sleepEM4)
		comp0_value = freqlo*time_p;

	LETIMER_CompareSet(LETIMER0, 0, comp0_value);

	while (LETIMER0->SYNCBUSY);

	LETIMER_IntClear(LETIMER0, LETIMER_IFC_UF | LETIMER_IFC_COMP0);
	LETIMER_IntEnable(LETIMER0, LETIMER_IEN_COMP0);

	//blockSleepMode(mode);
	NVIC_EnableIRQ(LETIMER0_IRQn);
	LETIMER0->CMD = LETIMER_CMD_START;
}

void LETIMER0_IRQHandler(void)
{
	CORE_ATOMIC_IRQ_DISABLE();
	int flags;
	flags = LETIMER_IntGet(LETIMER0);
	//LETIMER_IntClear(LETIMER0, flags);
	//long int limit = 4857142*led_on_time;
		if (LETIMER_IF_COMP0 & flags)
			{
				GPIO_PinOutClear(LED0_port, LED0_pin);
				LETIMER_IntClear(LETIMER0, LETIMER_IFC_COMP0 | LETIMER_IFC_UF);

				int comp1_value;
				if (mode == sleepEM0 || mode == sleepEM1 || mode == sleepEM2 || mode == sleepEM3)
					comp1_value = (freq/j)*led_on_time;
				else comp1_value = freqlo*led_on_time;
				LETIMER_CompareSet(LETIMER0, 1, comp1_value);
				LETIMER_IntClear(LETIMER0, LETIMER_IFC_COMP1);
				LETIMER_IntEnable(LETIMER0, LETIMER_IEN_COMP1);
				//LETIMER0->CMD = LETIMER_CMD_START;

				/*for (long int i=0;i<limit;i++)
					 GPIO_PinOutSet(LED0_port, LED0_pin);
				for (long int i=0;i<limit;i++)
					 GPIO_PinOutClear(LED0_port, LED0_pin);
	*/
	}
		if (LETIMER_IF_COMP1 & flags)
		{
					GPIO_PinOutSet(LED0_port, LED0_pin);
					LETIMER_IntClear(LETIMER0, LETIMER_IFC_COMP1 | LETIMER_IFC_UF);
		}
					CORE_ATOMIC_IRQ_ENABLE();
}

